import cv2 as cv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math as math
import tkinter as tk
import cv2 as cv
from tkinter import *
from PIL import ImageTk, Image

#Texting format
text1 = "Original Image"
text2 = "Segmented Image"
text3 = "Bounding box (A)"
text4 = "Bounding box (P)"
coordinates = (0,190)
font = cv.FONT_HERSHEY_SIMPLEX
fontScale = 0.6
color = (0,0,255)
thickness = 1

#array to store input dataset
dataset = []
#array to store ground truth coordinates
new_d_x1=[]
new_d_x2=[]
new_d_y1=[]
new_d_y2=[]

#Initialization
count=0
accurate=0
total = 0

#function to calculate IoU
def get_iou(ground_truth, pred):
    # coordinates of the area of intersection.
    ix1 = np.maximum(ground_truth[0], pred[0])
    iy1 = np.maximum(ground_truth[1], pred[1])
    ix2 = np.minimum(ground_truth[2], pred[2])
    iy2 = np.minimum(ground_truth[3], pred[3])
    
    # Intersection height and width.
    i_height = np.maximum(iy2 - iy1 + 1, np.array(0.))
    i_width = np.maximum(ix2 - ix1 + 1, np.array(0.))
    
    area_of_intersection = i_height * i_width
    
    # Ground Truth dimensions.
    gt_height = ground_truth[3] - ground_truth[1] + 1
    gt_width = ground_truth[2] - ground_truth[0] + 1
    
    # Prediction dimensions.
    pd_height = pred[3] - pred[1] + 1
    pd_width = pred[2] - pred[0] + 1
    
    area_of_union = gt_height * gt_width + pd_height * pd_width - area_of_intersection
    
    iou = area_of_intersection / area_of_union
    
    return iou

#function to find distance between a point in blue line and red line
def calc_distance(x1, y1, a, b, c):
    d = abs((a * x1 + b * y1 + c)) /(math.sqrt(a * a + b * b))
    return d

    


df = pd.read_excel('annotation.xlsx')
#100 datasets
for i in range(1, 101):
    dataset.append("img (%d).png" %(i))
    d_width=df._get_value(i-1,"width")
    d_height=df._get_value(i-1,"height")
    d_x1=df._get_value(i-1,"x1")
    d_y1=df._get_value(i-1,"y1")
    d_x2=df._get_value(i-1,"x2")
    d_y2=df._get_value(i-1,"y2")
    
    new_d_width=200/d_width
    new_d_height=200/d_height
    
    new_d_x1.append(d_x1*new_d_width)
    new_d_x2.append(d_x2*new_d_width)
    new_d_y1.append(d_y1*new_d_height)
    new_d_y2.append(d_y2*new_d_height)
    
for data in dataset:
    img = cv.imread(data)
    img = cv.resize(img, (200,200), interpolation = cv.INTER_CUBIC)
    img_filtered = cv.bilateralFilter(img, 7, 30, 30) 
    img_hsv = cv.cvtColor(img_filtered, cv.COLOR_BGR2HSV)
    h,s,v = cv.split(img_hsv)
    clahe = cv.createCLAHE(clipLimit = 2.0, tileGridSize = (8, 8))
    v_dst = clahe.apply(v)

    img_cl = img_hsv
    img_cl[:,:,2] = v_dst
    img_cl = cv.cvtColor(img_cl, cv.COLOR_HSV2BGR)

    img_hsv = cv.cvtColor(img_cl, cv.COLOR_BGR2HSV)

    img_reshape = img_hsv.reshape((-1, 3))
    img_reshape = np.float32(img_reshape)

    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    attempts = 10
    max_k = 10

    wc_sos = []

    for k in range(2, max_k+1):
        ret, _, _ = cv.kmeans(img_reshape, k, None, criteria, attempts, cv.KMEANS_PP_CENTERS)
        wc_sos.append(ret)

    a = wc_sos[0] - wc_sos[8]
    b = max_k - 2
    c1 = 2 * wc_sos[8]
    c2 = max_k * wc_sos[0]
    c = c1 - c2

    distance = []
    idx = 0
    for k in range(2, max_k+1):
        distance.append(calc_distance(k,wc_sos[idx], a, b, c))
        idx += 1

    K = np.argmax(distance)+2

    ret, label, center = cv.kmeans(img_reshape, K+1, None, criteria, attempts, cv.KMEANS_PP_CENTERS)

    center = np.uint8(center)
    res = center[label.flatten()]
    result = res.reshape(img_hsv.shape) 

    img_kmeans = cv.cvtColor(result, cv.COLOR_HSV2BGR)
    img_gray_kmeans = cv.cvtColor(img_kmeans, cv.COLOR_BGR2GRAY)
    ret, th = cv.threshold(img_gray_kmeans, 0 , 255 , cv.THRESH_BINARY_INV + cv.THRESH_OTSU)

    contours, hierachy = cv.findContours(th, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)

    falseContour = []
    maxArea, maxAreaIdx = 0, 0
    for idx, i in enumerate(contours):
        area = cv.contourArea(i)
        for cnt in i:
            if (cnt[0][0] == 0 or cnt[0][1] == 0):
                falseContour.append(idx)
                break
            elif (cnt[0][1] >= 195):
                falseContour.append(idx)
                break
            elif (cnt[0][0] >= 195):
                falseContour.append(idx)
                break
            elif(area <= 3000):
                falseContour.append(idx)
                break
                
    maxArea, maxAreaIdx = 0, 0
    for idx, i in enumerate(contours):
        if idx not in falseContour:
            area = cv.contourArea(i)
            #look for contour with largest area for bounding box
            if area > maxArea:
                maxArea = area
                maxAreaIdx = idx

    img_rect = img.copy()
    img_test=img.copy()
    for idx, i in enumerate(contours):
        if idx == maxAreaIdx:
            rect = cv.boundingRect(i)
    x,y,w,h = rect
    img_rect=cv.rectangle(img_rect,(x,y),(x+w,y+h),(0,255,0),2)
    img_test=cv.rectangle(img_test,(int(new_d_x1[count]),int(new_d_y1[count])),(int(new_d_x2[count]),int(new_d_y2[count])),(0,255,0),2)
    
    mask = np.zeros((200, 200), dtype =np.uint8)

    for idx, i in enumerate(contours):
        if idx not in falseContour:
            cv.drawContours(mask, contours, idx, (255,255,255), -1)

    mask_dilate = cv.dilate(mask, None, iterations = 3)

    img_segment = cv.bitwise_and(img,img,mask=mask_dilate)
    
    #Image calculation IOU
    ground_truth_bbox = np.array([new_d_x1[count],new_d_y1[count],new_d_x2[count],new_d_y2[count]], dtype=np.float32)
    prediction_bbox = np.array([x, y, x+w, y+h], dtype=np.float32)
    
    iou = 0
    iou = get_iou(ground_truth_bbox, prediction_bbox)
    print("Current Image: ", count + 1)
    print('IOU: ', iou)
    print()
    count+=1
    
    if iou>0.8:
        accurate+=1 

    #Putting text
    img = cv.putText(img, text1, coordinates, font, fontScale, color, thickness, cv.LINE_AA)
    img_segment = cv.putText(img_segment, text2, coordinates, font, fontScale, color, thickness, cv.LINE_AA)
    img_test = cv.putText(img_test, text3, coordinates, font, fontScale, color, thickness, cv.LINE_AA)
    img_rect = cv.putText(img_rect, text4, coordinates, font, fontScale, color, thickness, cv.LINE_AA)
    
    numpy_horizontal = np.hstack((img,img_segment,img_test,img_rect))
    cv.imshow('Traffic sign segmentation',numpy_horizontal)
    cv.waitKey(0)
    cv.destroyAllWindows()


